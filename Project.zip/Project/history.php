<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request History</title>
    <!-- Add your CSS file or inline styles here -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        
        .container {
            width: 100%;
            padding: 20px;
            box-sizing: border-box;
        }
        
        .history-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .history-table th, .history-table td {
            padding: 10px;
            border: 1px solid #ccc;
        }
        
        .history-table th {
            background-color: #f0f0f0;
        }
        
        .approved {
            background-color: #4CAF50;
            color: white;
        }
        
        .rejected {
            background-color: #f44336;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Request History</h2>
        <table class="history-table">
            <thead>
                <tr>
                    <th>Book Title</th>
                    <th>Author</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Include your database connection file
                include_once "db_connection.php";

                // Fetch data from database
                $sql = "SELECT b.book_title, b.author, ra.action
                        FROM book_requests b
                        LEFT JOIN request_actions ra ON b.id = ra.request_id";
                $result = $conn->query($sql);

                // Check if query was successful
                if ($result === false) {
                    die("Error executing the query: " . $conn->error);
                }

                // Check if there are rows in the result
                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["book_title"] . "</td>";
                        echo "<td>" . $row["author"] . "</td>";
                        echo "<td class='" . ($row["action"] === "approve" ? "approved" : "rejected") . "'>" . ucfirst($row["action"]) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='3'>No request history found.</td></tr>";
                }

                // Close database connection
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
