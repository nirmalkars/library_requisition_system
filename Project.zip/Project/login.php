<?php
session_start();

// Default username and password
$defaultUsername = "admin";
$defaultPassword = "password";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include your database connection file
    include_once "db_connection.php";

    // Get username and password from the form
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Check if the provided credentials match the default values
    if ($username === $defaultUsername && $password === $defaultPassword) {
        // Set session variables and redirect to dashboard
        $_SESSION['username'] = $username;
        header("Location: submit_request.php");
        exit();
    } else {
        // Password incorrect
        $error = "Invalid username or password.";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Library Requisition System - Login</title>
  <style>
    body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background-image: url('background.jpg'); /* Replace 'background.jpg' with your background image path */
        background-size: cover;
        background-position: center;
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .login-container {
        background-color: rgba(255, 255, 255, 0.8); /* Semi-transparent white background */
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.2); /* Drop shadow effect */
        width: 300px; /* Adjust container width */
    }

    .login-container h2 {
        text-align: center;
        margin-bottom: 20px;
    }

    .login-container .form-group {
        margin-bottom: 15px;
    }

    .login-container .form-group label {
        display: block;
        margin-bottom: 5px;
    }

    .login-container .form-group input[type="text"],
    .login-container .form-group input[type="password"] {
        width: calc(100% - 20px); /* Adjust input width */
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 16px;
        margin: 0 auto; /* Center the input */
        display: block; /* Make input a block element */
        box-sizing: border-box; /* Include padding and border in width calculation */
    }

    .login-container button {
        width: calc(100% - 20px); /* Adjust button width */
        padding: 10px;
        border: none;
        border-radius: 5px;
        background-color: #007bff;
        color: #fff;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
        margin: 0 auto; /* Center the button */
        display: block; /* Make button a block element */
        box-sizing: border-box; /* Include padding and border in width calculation */
    }

    .login-container button:hover {
        background-color: #0056b3;
    }

    .error {
        color: #ff0000;
        text-align: center;
        margin-bottom: 10px;
    }
  </style>
</head>
<body>
  <div class="login-container">
    <h2>Login to Library Requisition System</h2>
    <?php if(isset($error)) { ?>
    <div class="error"><?php echo $error; ?></div>
    <?php } ?>
    <form id="loginForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
      <div class="form-group">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
      </div>
      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
      </div>
      <button type="submit">Login</button>
    </form>
  </div>
</body>
</html>
