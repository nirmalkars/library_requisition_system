-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2024 at 08:46 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `username` varchar(11) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`username`, `password`) VALUES
('admin', 'password'),
('admincse', 'CSE'),
('adminciv', 'CIVIL'),
('adminchem', 'CHEM');

-- --------------------------------------------------------

--
-- Table structure for table `book_requests`
--

CREATE TABLE `book_requests` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `book_title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `isbn` varchar(255) NOT NULL,
  `publication` varchar(255) NOT NULL,
  `edition` varchar(255) NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `class` varchar(10) NOT NULL,
  `department` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_requests`
--

INSERT INTO `book_requests` (`id`, `username`, `book_title`, `author`, `isbn`, `publication`, `edition`, `quantity`, `class`, `department`) VALUES
(1, 'admin', 'a', 'a', '123', '12', '1', '2', 'B-TECH', 'CHE'),
(2, 'admin', 'The Alchemist', 'Paulo Coelho', ' 978-0061122', 'HarperOne', '25', '12', 'TY', 'CHE'),
(3, 'admin', 'Harry Potter and the Phil', ' J.K. Rowling', '978-05903534', 'Bloomsbury Publishin', '0', '14', 'B-TECH', 'CHE'),
(4, 'admin', 'The Catcher in the Rye', 'J.D. Salinger', '978-0316769488', 'Little, Brown and Company', '0', '8', 'FY', 'CSE'),
(5, 'admin', 'Pride and Prejudice', ' Jane Austen', '978-0141439518', ' Penguin Classics', '0', '12', 'FY', 'CSE');

-- --------------------------------------------------------

--
-- Table structure for table `request_actions`
--

CREATE TABLE `request_actions` (
  `id` int(11) NOT NULL,
  `request_id` varchar(255) DEFAULT NULL,
  `action` varchar(10) DEFAULT NULL,
  `action_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `request_actions`
--

INSERT INTO `request_actions` (`id`, `request_id`, `action`, `action_date`) VALUES
(13, '1', 'approve', '2024-05-02 18:40:11'),
(14, '2', 'approve', '2024-05-02 18:40:40'),
(15, '3', 'approve', '2024-05-02 18:42:15'),
(16, '4', 'reject', '2024-05-02 18:42:35'),
(17, '5', 'approve', '2024-05-02 18:43:55');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(11) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`) VALUES
('admin', 'password');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `request_actions`
--
ALTER TABLE `request_actions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `request_actions`
--
ALTER TABLE `request_actions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
