<?php
session_start(); // Start or resume the session

$message = ""; // Initialize message variable

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // If the form is submitted, process the login
    if(isset($_POST["username"]) && isset($_POST["password"])) {
        // Default username and password
        $defaultUsername = "admin";
        $defaultPassword = "password";
        
        // Get username and password from the form
        $username = $_POST["username"];
        $password = $_POST["password"];

        // Check if the provided credentials match the default ones
        if ($username === $defaultUsername && $password === $defaultPassword) {
            // Set session variables and redirect to submit_request.php
            $_SESSION['username'] = $username;
            header("Location: submit_request.php");
            exit();
        } else {
            // Password incorrect
            $error = "Invalid username or password.";
        }
    }

    // If the user is not logged in, redirect to login.php
    if (!isset($_SESSION['username'])) {
        header("Location: login.php");
        exit();
    }

    // Connect to MySQL database
    $servername = "localhost";
    $db_username = "root"; // Changed to avoid conflict with username from form
    $db_password = "";
    $dbname = "library_db";
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the last inserted book ID
    $sql_last_id = "SELECT MAX(id) as max_id FROM book_requests";
    $result_last_id = $conn->query($sql_last_id);
    $last_id_row = $result_last_id->fetch_assoc();
    $last_id = $last_id_row['max_id'];
    $next_id = $last_id + 1; // Increment the last ID for the next request

    // Get data from form
    $id = $next_id; // Assign the next ID
    $book_titles = $_POST["book_title"];
    $authors = $_POST["author"];
    $isbns = $_POST["isbn"];
    $publications = $_POST["publication"];
    $editions = $_POST["edition"];
    $quantitys = $_POST["quantity"];
    $class_name = $_POST["class"]; // Renamed from `class` to avoid conflict
    $department = $_POST["department"];

    // Count the number of books submitted
    $num_books = count($book_titles);

    // Prepare and bind SQL statement
    $stmt = $conn->prepare("INSERT INTO book_requests (id, username, book_title, author, isbn, publication, edition, quantity, class, department) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        die("Error preparing statement: " . $conn->error);
    }

    // Execute prepared statement in a loop
    for ($i = 0; $i < $num_books; $i++) {
        // Bind parameters
        $stmt->bind_param("isssssisss", $id, $_SESSION['username'], $book_titles[$i], $authors[$i], $isbns[$i], $publications[$i], $editions[$i], $quantitys[$i], $class_name, $department);
        
        // Execute statement
        if (!$stmt->execute()) {
            echo "Error submitting book request: " . $stmt->error;
            break;
        }

        // Increment ID for the next request
        $id++;
    }

    $message = "Data added successfully!"; // Set success message

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Submit Book Request</title>
  <link rel="stylesheet" href="Style.css">
</head>
<body>
  <div class="request-container">
    <h2>Welcome, <?php echo $_SESSION['username']; ?>!</h2>
    <h2>Submit Book Request</h2>
    <?php if (!empty($message)) : ?>
      <div class="message"><?php echo $message; ?></div>
      <script>
        alert("<?php echo $message; ?>"); // Display popup message
      </script>
    <?php endif; ?>
    <form id="requestForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
      <div class="form-group">
        <label for="department">Department:</label>
        <select name="department" id="department">
          <option value="CSE">CSE</option>
          <option value="CE">CE</option>
          <option value="CHE">CHE</option>
          <option value="MECH">MECH</option>
          <option value="ENTC">ENTC</option>
        </select>
      </div>
      <div class="form-group">
        <label for="class">Class:</label>
        <select name="class" id="class">
          <option value="FY">FY</option>
          <option value="SY">SY</option>
          <option value="TY">TY</option>
          <option value="B-TECH">B-TECH</option>
        </select>
      </div>
      <div id="books">
        <div class="book">
          <div class="form-group">
            <label for="book_title">Book Title:</label>
            <input type="text" name="book_title[]" required>
          </div>
          <div class="form-group">
            <label for="author">Author:</label>
            <input type="text" name="author[]" required>
          </div>
          <div class="form-group">
            <label for="isbn">ISBN:</label>
            <input type="text" name="isbn[]" required>
          </div>
          <div class="form-group">
            <label for="publication">Publication:</label>
            <input type="text" name="publication[]" required>
          </div>
          <div class="form-group">
            <label for="edition">Edition:</label>
            <input type="text" name="edition[]" required>
          </div>
          <div class="form-group">
            <label for="quantity">Quantity:</label>
            <input type="text" name="quantity[]" required>
          </div>
        </div>
      </div>
      
      <button type="button" id="addBook">Add Another Book</button><br><br>
      <button type="submit">Submit Request</button>
    </form>

    <!-- History Button -->
    <form action="history.php" method="get">
      <button type="submit">History</button>
    </form>
  </div>

  <script>
    document.getElementById('addBook').addEventListener("click", function() {
      var booksContainer = document.getElementById("books");
      var bookDiv = document.createElement("div");
      bookDiv.classList.add("book");
      bookDiv.innerHTML = `
        <div class="form-group">
          <label for="book_title">Book Title:</label>
          <input type="text" name="book_title[]" required>
        </div>
        <div class="form-group">
          <label for="author">Author:</label>
          <input type="text" name="author[]" required>
        </div>
        <div class="form-group">
          <label for="isbn">ISBN:</label>
          <input type="text" name="isbn[]" required>
        </div>
        <div class="form-group">
          <label for="publication">Publication:</label>
          <input type="text" name="publication[]" required>
        </div>
        <div class="form-group">
          <label for="edition">Edition:</label>
          <input type="text" name="edition[]" required>
        </div>
        <div class="form-group">
          <label for="quantity">Quantity:</label>
          <input type="text" name="quantity[]" required>
        </div>
      `;
      booksContainer.appendChild(bookDiv);
    });
  </script>
</body>
</html>
