<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        /* Reset default browser styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body styles */
        body {
            font-family: Arial, sans-serif;
            background-image: url('background.jpg'); /* Replace 'background_image.jpg' with the path to your image */
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            background-color: #f5f5f5; /* Fallback color if image is not available */
            min-height: 100vh; /* Ensure the background covers the entire viewport */
            display: flex; /* Center the login container */
            justify-content: center; /* Center the login container */
            align-items: center; /* Center the login container */
        }

        /* Container styles */
        .login-container {
            max-width: 400px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        /* Form styles */
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Admin Login</h2>
        <form action="admin_dashboard.php" method="post">
            <div>
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <br>
            <button type="submit">Login</button>
        </form>
    </div>

    <?php
    session_start();

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Include your database connection file
        include_once "db_connection.php";

        // Get username and password from the form
        $username = $_POST["username"];
        $password = $_POST["password"];

        // Prepare SQL statement to fetch admin data
        $stmt = $conn->prepare("SELECT * FROM admins WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            // Admin found, verify password
            $admin = $result->fetch_assoc();
            if (password_verify($password, $admin['password'])) {
                // Password correct, set session variable and redirect to admin dashboard
                $_SESSION['admin'] = $username;
                header("Location: admin_dashboard.html");
                exit();
            } else {
                // Password incorrect
                $error = "Invalid username or password.";
            }
        } else {
            // Admin not found
            $error = "Invalid username or password.";
        }

        $stmt->close();
        $conn->close();
    }
    ?>
</body>
</html>
