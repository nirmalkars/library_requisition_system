<?php
// Include your database connection file
include_once "db_connection.php";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get data from form
    $request_id = $_POST["request_id"];
    $action = $_POST["action"]; // 'approve' or 'reject'

    // Prepare and execute SQL statement to insert action into database
    $stmt = $conn->prepare("INSERT INTO request_actions (request_id, action) VALUES (?, ?)");
    $stmt->bind_param("is", $request_id, $action);
    
    // Check if the statement was prepared successfully
    if ($stmt) {
        // Execute the statement
        $stmt->execute();

        // Check if any rows were affected
        if ($stmt->affected_rows > 0) {
            // Redirect back to admin dashboard after processing action
            header("Location: admin_dashboard.php");
            exit();
        } else {
            // Handle the case where no rows were affected
            echo "Error: No rows were affected.";
        }
    } else {
        // Handle the case where the statement preparation failed
        echo "Error preparing statement: " . $conn->error;
    }

    // Close the statement
    $stmt->close();
}
?>
