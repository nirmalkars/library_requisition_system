<?php
// Include your database connection file
include_once "db_connection.php";

// Check if edition is provided and not empty
if(isset($_POST['edition']) && !empty($_POST['edition'])) {
    // Sanitize the input to prevent SQL injection
    $edition = $_POST['edition'];

    // Prepare and execute the SQL DELETE query
    $sql = "DELETE FROM book_requests WHERE edition = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $edition); // Assuming edition is a string
    $stmt->execute();

    // Check if the deletion was successful
    if ($stmt->affected_rows > 0) {
        // Deletion successful, redirect back to admin dashboard or display success message
        header("Location: admin_dashboard.php");
        exit();
    } else {
        // Deletion failed, display an error message or handle as needed
        echo "Error: Unable to delete the request.";
    }

    // Close statement
    $stmt->close();
} else {
    // Edition not provided or empty, display an error message or handle as needed
    echo "Error: Edition not provided.";
}

// Close database connection
$conn->close();
?>
