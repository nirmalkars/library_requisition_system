<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <!-- Add your CSS file or inline styles here -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        
        .container {
            width: 100%;
            padding: 20px;
            box-sizing: border-box;
        }
        
        .request-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .request-table th, .request-table td {
            padding: 10px;
            border: 1px solid #ccc;
        }
        
        .request-table th {
            background-color: #f0f0f0;
        }
        
        .action-buttons {
            display: flex;
            justify-content: space-between;
        }
        
        .action-buttons button {
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .approve-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
        }
        
        .reject-btn {
            background-color: #f44336;
            color: white;
            border: none;
        }
        
        .delete-btn {
            background-color: #555555;
            color: white;
            border: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Book Requests</h2>
        <table class="request-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Book Title</th>
                    <th>Author</th>
                    <th>ISBN</th>
                    <th>Publication</th>
                    <th>Edition</th>
                    <th>Quantity</th>
                    <th>Class</th>
                    <th>Department</th>
                    <th>Username</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Include your database connection file
                include_once "db_connection.php";

                // Fetch data from database
                $sql = "SELECT id, book_title, author, isbn, publication, edition, quantity, class, department, username FROM book_requests";
                $result = $conn->query($sql);

                // Check if query was successful
                if ($result === false) {
                    die("Error executing the query: " . $conn->error);
                }

                // Check if there are rows in the result
                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["id"] . "</td>";
                        echo "<td>" . $row["book_title"] . "</td>";
                        echo "<td>" . $row["author"] . "</td>";
                        echo "<td>" . $row["isbn"] . "</td>";
                        echo "<td>" . $row["publication"] . "</td>";
                        echo "<td>" . $row["edition"] . "</td>";
                        echo "<td>" . $row["quantity"] . "</td>";
                        echo "<td>" . $row["class"] . "</td>";
                        echo "<td>" . $row["department"] . "</td>";
                        echo "<td>" . $row["username"] . "</td>";
                        echo "<td class='action-buttons'>";
                        echo "<form action='process_action.php' method='post'>";
                        echo "<input type='hidden' name='request_id' value='" . $row['id'] . "'>";
                        echo "<button type='submit' name='action' value='approve' class='approve-btn'>Approve</button>";
                        echo "<button type='submit' name='action' value='reject' class='reject-btn'>Reject</button>";
                        echo "</form>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='11'>No book requests found.</td></tr>";
                }

                // Close database connection
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
